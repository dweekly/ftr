//! Global configuration modules

pub mod timing;
